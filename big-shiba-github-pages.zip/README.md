# Big Shiba Coin — site para GitHub Pages

Site estático preparado para hospedagem no GitHub Pages. A arte da mulher Shiba, o menu e o painel de recompensas foram mantidos.

## Como publicar

1. Na sua conta GitHub, crie um repositório público `big-shiba-coin` (com README opcional).
2. Na aba **Code**, clique em **Add file > Upload files**.
3. Envie para a raiz os arquivos `index.html`, `payments.js`, `payments.json` e `.nojekyll`, depois clique em **Commit changes**.
4. Abra **Settings > Pages**. Em **Build and deployment**, escolha **Deploy from a branch**, selecione **main** e **/(root)** e salve.
5. Após o deploy, o endereço normalmente será `https://SEU-USUARIO.github.io/big-shiba-coin/`.

## Dados de pagamentos

A lista inicia vazia e usa `payments.json`. Valores de status `paid` só devem ser publicados com comprovação real de transferência em blockchain. O contador do painel é um cálculo local, não um depósito nem mineração verdadeira. O armazenamento da carteira em cada navegador não equivale a cadastro em servidor.
